package bean;

public class Comment {

	private int userid;//userid //id

	private int orderid; //orderNum

	private String comment;//comment

	public Comment() {

		userid = 0;
		orderid = 0;
		comment = null;
	}

	//getter,setter
	public int getUserId() {
		return userid;
	}

	public void setUserId(int userid) {
		this.userid = userid;
	}

	public int getOrderId() {
		return orderid;
	}

	public void setOrderId(int orderid) {
		this.orderid = orderid;
	}

	public String getComment() {
		return comment;
	}

	//
	public void setComment(String comment) {
		this.comment = comment;
	}
}