package dao;

import java.sql.*;

import bean.Order;
import java.util.ArrayList;

import javax.servlet.http.HttpSession;

public class OrderDAO {

	// DB情報をフィールド変数に定義
	private static String RDB_DRIVE = "com.mysql.jdbc.Driver";
	private static String URL = "jdbc:mysql://localhost/uniformdb";
	private static String USER = "root";
	private static String PASSWD = "root123";

	// getConnectionメソッド準備
	public static Connection getConnection() {
		try {
			Class.forName(RDB_DRIVE);
			Connection con = DriverManager.getConnection(URL, USER, PASSWD);
			return con;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

	// 引数の購入データを元にDBのorder_infoテーブルに新規登録処理を行うメソッド定義
	public void insert(Order order) {
		Connection con = null;
		Statement smt = null;
		try {

		//6.29-SQL更新しました
		String sql = "INSERT INTO order_info VALUES(NULL,'" + order.getUserid() + "','" + order.getProductid() + "','"
				+ order.getQuantity() + "',CURDATE() ,'" + 1 + "','" + 1 + "')";

			con = getConnection();
			smt = con.createStatement();
			smt.executeUpdate(sql);
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

	// 引数の注文Noを元にDBのorder_infoテーブルから該当オーダーデータの更新処理を行うメソッド定義
	public void orderpaymentUpdate(String orderid) {

		String sql = "UPDATE order_info SET payment_status='2'" + "WHERE order_id='"+ orderid + "'";
		Connection con = null;
		Statement smt = null;

		try {
				con = getConnection();
			smt = con.createStatement();
			smt.executeUpdate(sql);
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

	// 引数の書籍データを元にDBのorder_infoテーブルから該当オーダーデータの更新処理を行うメソッド定義
		public void ordershippingUpdate(String orderid) {

			String sql = "UPDATE order_info SET shipping_status='2'" + "WHERE order_id='"+ orderid + "'";
			Connection con = null;
			Statement smt = null;

			try {
				con = getConnection();
				smt = con.createStatement();
				smt.executeUpdate(sql);
			} catch (Exception e) {
				throw new IllegalStateException(e);
			} finally {
				if (smt != null) {
					try {
						smt.close();
					} catch (SQLException ignore) {
					}
				}
				if (con != null) {
					try {
						con.close();
					} catch (SQLException ignore) {
					}
				}
			}
		}

		//6.27追加文
		public int update(Order order) {

			Connection con = null;
			Statement smt = null;

			//return用変数
			int count =0;

			try {
				con = getConnection();
				smt = con.createStatement();

				//SQL文の準備
				String sql = "UPDATE ordertable SET shipping="+order.getShipping() +",payment=" +order.getPayment()+" WHERE orderid="
															+order.getOrderid()+"";

				count =smt.executeUpdate(sql);		//ここでSQL文発行

			}catch (Exception e) {
				throw new IllegalStateException(e);
			} finally {
				if (smt != null) {try {smt.close();} catch (SQLException ignore) {}}
				if (con != null) {try {con.close();} catch (SQLException ignore) {}}
			}
			return count;
		}


		//6.27追加した
		//orderidから情報詳細を取る
		public ArrayList<Order> selectByOrderId(int orderid){

			Connection con = null;
			Statement smt = null;

			//return用変数
			ArrayList<Order> orderList = new ArrayList<Order>();

			try {
				con = getConnection();
				smt = con.createStatement();



				//SQL文の準備
				String sql = "SELECT * FROM ordertable WHERE orderid=" + orderid + "";

				ResultSet rs = smt.executeQuery(sql); // ここでSQL文発行

				// 値を格納
				while (rs.next()) {
					Order order = new Order();

					order.setOrderid(rs.getInt("orderid"));

					order.setProductid(rs.getString("productid"));
					order.setQuantity(rs.getInt("quantity"));

					order.setName(rs.getString("name"));
					order.setEmail(rs.getString("email"));
					order.setAddress(rs.getString("address"));

					order.setDate(rs.getString("date"));
					order.setShipping(rs.getString("shipping"));
					order.setPayment(rs.getString("payment"));

					orderList.add(order);
				}

			}catch (Exception e) {
				throw new IllegalStateException(e);
			} finally {
				if (smt != null) {try {smt.close();} catch (SQLException ignore) {}}
				if (con != null) {try {con.close();} catch (SQLException ignore) {}}
			}

			return orderList;
		}

		//6.27追加した
		//一番最新の注文の番号（orderId)を取得する
			public int getLatestOrderId() {

				Connection con = null;
				Statement smt = null;

				//return用変数
				int orderid =0;

				try {
					con = getConnection();
					smt = con.createStatement();

					//SQL文の準備
					String sql = "SELECT max(orderid) orderid from ordertable";

					ResultSet rs = smt.executeQuery(sql); // SQL文発行

					if (rs.next()) {
						orderid = rs.getInt("orderid");
					}

				}catch (Exception e) {
					throw new IllegalStateException(e);
				} finally {
					if (smt != null) {try {smt.close();} catch (SQLException ignore) {}}
					if (con != null) {try {con.close();} catch (SQLException ignore) {}}
				}

				return orderid;
			}


}
