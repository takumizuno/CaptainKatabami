package servlet;

import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;

import bean.OrderAdminItem;
import dao.OrderAdminItemDAO;

public class OrderDetailsServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//エラー処理の為の変数を宣言
		String error = "";
		String cmd = "";

		try {
			// 文字コード指定
			request.setCharacterEncoding("UTF-8");

			// リクエストスコープに登録されているorderidとcmdを取得
			String order_id = request.getParameter("orderid");
			cmd = request.getParameter("cmd");

			// DAOオブジェクト化
			OrderAdminItemDAO objDao = new OrderAdminItemDAO();

			OrderAdminItem adminItem = objDao.selectDetailAll(order_id);

			// 詳細情報のエラーチェック
			if (adminItem.getOrderid() == null) {
				if (cmd.equals("detail")) {
					error = "表示対象の注文が存在しない為、詳細情報は表示できませんでした。";
				}
				cmd = "list";
				return;
			}

			// リクエストスコープに登録
			request.setAttribute("adminItem", adminItem);

		} catch (IllegalStateException e) {
			if (cmd.equals("detail")) {
				error = "DB接続エラーの為、詳細は表示できませんでした。";
			} else if (cmd.equals("update")) {
				error = "DB接続エラーの為、変更画面は表示できませんでした。";
			}
			cmd = "menu";
		} finally {

			// エラーの有無でフォワード先を呼び分ける
			if (error.equals("")) {
				// ⑤ cmdの値でフォワード先を変更
				if (cmd.equals("detail")) {
					request.getRequestDispatcher("/view/orderDetails.jsp").forward(request, response);
				}

			} else {
				// エラーがあるerror.jspにフォワードする
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);

			}

		}
	}
}