package servlet;

import java.io.*;
import java.util.ArrayList;

import javax.servlet.*;
import javax.servlet.http.*;
import bean.*;
import dao.*;

public class UserInsertServlet extends HttpServlet {

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		User user = new User();
		String cmd = null;
		ArrayList<String> error = new ArrayList<String>();

		request.setCharacterEncoding("UTF-8");

		String username = request.getParameter("username");
		String userid = request.getParameter("userid");
		String password = request.getParameter("password");
		String email = request.getParameter("email");
		String address = request.getParameter("address");

		try {
			if (username == null || username.equals("")) {
				error.add("氏名が未入力です。");
				cmd = "return";
			}
			if (userid == null || userid.equals("")) {
				error.add("IDが未入力です。");
				cmd = "return";
			}
			if (password == null || password.equals("")) {
				error.add("パスワードが未入力です。");
				cmd = "return";
			}
			if (email == null || email.equals("")) {
				error.add("メールアドレスが未入力です。");
				cmd = "return";
			}
			if (address == null || address.equals("")) {
				error.add("住所が未入力です。");
				cmd = "return";
			}

			UserDAO userDao = new UserDAO();
			user = userDao.selectByUser(userid, password);
			user = userDao.selectByEmail(email);

			if (user.getUserid() != null) {
				error.add("入力されたユーザーIDは既に登録済の為、会員登録は行えません。");
				cmd = "return";
			}
//			if (user.getEmail() != null) {
//				error.add("入力されたメールアドレスは既に登録済の為、会員登録は行えません。");
//				cmd = "return";
//			}
			if (error.size() > 0) {
				request.setAttribute("error", error);
				return;
			} else {

				User User = new User();
				User.setUsername(username);
				User.setUserid(userid);
				User.setPassword(password);
				User.setEmail(email);
				User.setAddress(address);
				User.setAuthority("2");

				userDao.insertUser(User);
				cmd = "menu";
			}

		} catch (IllegalStateException e) {
			String msg = "DB接続エラーの為、新規会員登録は行えません。";
			cmd = "menu";
			request.setAttribute("error", msg);
			request.setAttribute("cmd", cmd);
			request.getRequestDispatcher("/view/error.jsp").forward(request, response);
		} finally {
			if (cmd == "menu") {
				request.getRequestDispatcher("/view/login.jsp").forward(request, response);
			} else if (cmd == "return") {
				request.getRequestDispatcher("/view/userInsert.jsp").forward(request, response);
			}
		}
	}
}