package util;

import java.text.DecimalFormat;

public class MoneyFormat {

	public String moneyFormat(int price) {
		DecimalFormat df = new DecimalFormat("\u00A5###,##0");
		return df.format(price);
	}

}
