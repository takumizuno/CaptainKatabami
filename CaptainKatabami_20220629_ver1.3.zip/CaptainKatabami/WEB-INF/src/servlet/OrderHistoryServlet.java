package servlet;

import java.io.*;
import java.util.ArrayList;
import javax.servlet.*;
import javax.servlet.http.*;
import bean.OrderUserItem;
import bean.User;
import dao.OrderUserItemDAO;

public class OrderHistoryServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String error = "";
		String cmd = "";

		try {

			HttpSession session = request.getSession();
			User user = (User)session.getAttribute("user");

			OrderUserItemDAO orderUserItemDao = new OrderUserItemDAO();

			ArrayList<OrderUserItem> ordered_list = orderUserItemDao.selectAll(user);

			request.setAttribute("ordered_list", ordered_list);

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、注文履歴表示は出来ません。";
			cmd = "logout";
		} finally {
			if (error.equals("")) {
				request.getRequestDispatcher("/view/orderHistory.jsp").forward(request, response);
			} else {
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}
}