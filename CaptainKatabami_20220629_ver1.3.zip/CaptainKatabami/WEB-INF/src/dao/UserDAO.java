package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import bean.User;

public class UserDAO {

	// DB情報をフィールド変数に定義
	private static String RDB_DRIVE = "com.mysql.jdbc.Driver";
	private static String URL = "jdbc:mysql://localhost/uniformdb";
	private static String USER = "root";
	private static String PASSWD = "root123";

	// getConnectionメソッド準備
	public static Connection getConnection() {
		try {
			Class.forName(RDB_DRIVE);
			Connection con = DriverManager.getConnection(URL, USER, PASSWD);
			return con;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

	/*
	 * ユーザー情報 DBのuser_infoテーブルから指定ユーザーの条件に合致する情報を取得するメソッド定義
	 */
	public User selectByUser(String userid, String password) {

		User user = new User();
		String sql = "SELECT * FROM user_info WHERE user_id ='" + userid + "' AND user_password='" + password + "'";
		Connection con = null;
		Statement smt = null;

		try {
			con = getConnection();
			smt = con.createStatement();
			ResultSet rs = smt.executeQuery(sql);
			if (rs.next()) {
				user.setUserid(rs.getString("user_id"));
				user.setPassword(rs.getString("user_password"));
				user.setUsername(rs.getString("user_name"));
				user.setEmail(rs.getString("mailaddress"));
				user.setAuthority(rs.getString("authority"));
				user.setAddress(rs.getString("address"));
			}
			return user;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

	public User selectByUser(String userid) {

		User user = new User();
		String sql = "SELECT * FROM user_info WHERE user_id =" + userid;
		Connection con = null;
		Statement smt = null;

		try {
			con = getConnection();
			smt = con.createStatement();
			ResultSet rs = smt.executeQuery(sql);
			if (rs.next()) {
				user.setUserid(rs.getString("user_id"));
				user.setPassword(rs.getString("user_password"));
				user.setUsername(rs.getString("user_name"));
				user.setEmail(rs.getString("mailaddress"));
				user.setAuthority(rs.getString("authority"));
				user.setAddress(rs.getString("address"));
			}
			return user;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}



	/*
	 *  インサートメソッド
	 */
	public void insertUser(User user) {
		Connection con = null;
		Statement smt = null;

		String sql = "INSERT INTO user_info VALUES('" + user.getUserid() + "','" + user.getPassword() + "','"
				+ user.getUsername() + "','" + user.getEmail() + "','" + user.getAddress() + "','"
				+ user.getAuthority() + "')";


		try {
			con = getConnection();
			smt = con.createStatement();


			smt.executeUpdate(sql);

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

	/*
	 *  メールアドレス取得
	 */
	public User selectByEmail(String email) {

		Connection con = null;
		Statement smt = null;

		User user = new User();

		try {
			String sql = "SELECT * FROM user_info WHERE mailaddress = '" + email + "'";

			con = getConnection();
			smt = con.createStatement();

			ResultSet rs = smt.executeQuery(sql);

			while (rs.next()) {
				user.setUserid(rs.getString("userid"));
				user.setUsername(rs.getString("username"));
				user.setPassword(rs.getString("password"));
				user.setEmail(rs.getString("email"));
				user.setAuthority(rs.getString("authority"));
			}
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}

		return user;
	}

	/*
	 *  ユーザー情報更新メソッド
	 */
	public void updateUser(User user) {

		Connection con = null;
		Statement smt = null;

		String sql = "UPDATE user_info SET user_name='" + user.getUsername() + "',user_password='" + user.getPassword() + "',mailaddress='" + user.getEmail() + "',address='"
				+ user.getAddress() + "' WHERE user_id='" + user.getUserid() + "'";

		try {

			con = getConnection();
			smt = con.createStatement();

			smt.executeUpdate(sql);

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

	/*
	 * 管理者情報 DBのadmin_infoテーブルから指定ユーザーの条件に合致する情報を取得するメソッド定義
	 */
	public User selectByAdmin(String userid, String password) {

		User user = new User();
		String sql = "SELECT * FROM admin_info WHERE admin_id ='" + userid + "' AND admin_password='" + password + "'";

		Connection con = null;
		Statement smt = null;

		try {
			con = getConnection();
			smt = con.createStatement();
			ResultSet rs = smt.executeQuery(sql);
			if (rs.next()) {
				user.setUserid(rs.getString("admin_id"));
				user.setPassword(rs.getString("admin_password"));
				user.setUsername(rs.getString("admin_name"));
				user.setAuthority(rs.getString("authority"));
			}
			return user;

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

}
