package util;

import java.util.Properties;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;

import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Message;
import javax.mail.Transport;
import javax.mail.internet.MimeMessage;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.*;
import dao.*;

import javax.mail.internet.InternetAddress;

public class SendMail {

	public void sendMailBuy(User user, ArrayList<Product> product_list) {
		try {
			// Lineに購入情報を格納
			String Line = "";
			int total = 0;
			if (product_list != null) {
				for (Product product : product_list) {
					total += product.getPrice();
					Line += product.getProductid() + " " + product.getProductname() + " " + product.getPrice() + "円\n";
				}
			}
			Properties props = System.getProperties();

			// SMTPサーバのアドレスを指定（今回はxserverのSMTPサーバを利用）
			props.put("mail.smtp.host", "sv5215.xserver.jp");
			props.put("mail.smtp.auth", "true");
			props.put("mail.smtp.starttls.enable", "true");
			props.put("mail.smtp.port", "587");
			props.put("mail.smtp.debug", "true");

			Session session = Session.getInstance(props, new javax.mail.Authenticator() {
				protected PasswordAuthentication getPasswordAuthentication() {
					// メールサーバにログインするメールアドレスとパスワードを設定
					return new PasswordAuthentication("system.project.team38@kanda-it-school-system.com", "uQ77qq52hb");
				}
			});

			MimeMessage mimeMessage = new MimeMessage(session);

			// 送信元メールアドレスと送信者名を指定
			mimeMessage
					.setFrom(new InternetAddress("system.project.team38@kanda-it-school-system.com", "キャプテンKATABAMI", "iso-2022-jp"));

			// 送信先メールアドレスを指定（テスト用に自分に返ってくるメールアドレス設定してます）
			mimeMessage.setRecipients(Message.RecipientType.TO, "system.project.team38@kanda-it-school-system.com");

			// メールのタイトルを指定
			mimeMessage.setSubject("購入ありがとうございます。", "iso-2022-jp");

			// メールの内容を指定
			mimeMessage.setText(user.getUsername() + "様\n\nユニフォームのご購入ありがとうございます。\n以下内容でご注文を受け付けましたので、ご連絡いたします。\n\n" + Line
					+ "\n合計" + total + "円\n\nまたのご利用よろしくお願いします。", "iso-2022-jp");

			// メールの形式を指定
			mimeMessage.setHeader("Content-Type", "text/plain; charset=iso-2022-jp");

			// 送信日付を指定
			mimeMessage.setSentDate(new Date());

			// 送信します
			Transport.send(mimeMessage);

			// 送信成功
			System.out.println("送信に成功しました。");

		} catch (Exception e) {
			// e.printStackTrace();
			System.out.println("送信に失敗しました。\n" + e);
		}
	}

	public void sendMailPayment() {
		try {
			Properties props = System.getProperties();

			// SMTPサーバのアドレスを指定（今回はxserverのSMTPサーバを利用）
			props.put("mail.smtp.host", "sv5215.xserver.jp");
			props.put("mail.smtp.auth", "true");
			props.put("mail.smtp.starttls.enable", "true");
			props.put("mail.smtp.port", "587");
			props.put("mail.smtp.debug", "true");

			Session session = Session.getInstance(props, new javax.mail.Authenticator() {
				protected PasswordAuthentication getPasswordAuthentication() {
					// メールサーバにログインするメールアドレスとパスワードを設定
					return new PasswordAuthentication("system.project.team38@kanda-it-school-system.com", "uQ77qq52hb");
				}
			});

			MimeMessage mimeMessage = new MimeMessage(session);

			// 送信元メールアドレスと送信者名を指定
			mimeMessage
					.setFrom(new InternetAddress("system.project.team38@kanda-it-school-system.com", "キャプテンKATABAMI", "iso-2022-jp"));

			// 送信先メールアドレスを指定（テスト用に自分に返ってくるメールアドレス設定してます）
			mimeMessage.setRecipients(Message.RecipientType.TO, "e1randsubs@gmail.com");

			// メールのタイトルを指定
			mimeMessage.setSubject("入金確認しました。", "iso-2022-jp");

			// メールの内容を指定
			mimeMessage.setText("user.getUsername()" + "様\n\n入金確認しました。\n\nまたのご利用よろしくお願いします。", "iso-2022-jp");

			// メールの形式を指定
			mimeMessage.setHeader("Content-Type", "text/plain; charset=iso-2022-jp");

			// 送信日付を指定
			mimeMessage.setSentDate(new Date());

			// 送信します
			Transport.send(mimeMessage);

			// 送信成功
			System.out.println("送信に成功しました。");

		} catch (Exception e) {
			// e.printStackTrace();
			System.out.println("送信に失敗しました。\n" + e);
		}
	}

	public void sendMailShipping(User user) {
		try {
			Properties props = System.getProperties();

			// SMTPサーバのアドレスを指定（今回はxserverのSMTPサーバを利用）
			props.put("mail.smtp.host", "sv5215.xserver.jp");
			props.put("mail.smtp.auth", "true");
			props.put("mail.smtp.starttls.enable", "true");
			props.put("mail.smtp.port", "587");
			props.put("mail.smtp.debug", "true");

			Session session = Session.getInstance(props, new javax.mail.Authenticator() {
				protected PasswordAuthentication getPasswordAuthentication() {
					// メールサーバにログインするメールアドレスとパスワードを設定
					return new PasswordAuthentication("system.project.team38@kanda-it-school-system.com", "uQ77qq52hb");
				}
			});

			MimeMessage mimeMessage = new MimeMessage(session);

			// 送信元メールアドレスと送信者名を指定
			mimeMessage
					.setFrom(new InternetAddress("system.project.team38@kanda-it-school-system.com", "キャプテンKATABAMI", "iso-2022-jp"));

			// 送信先メールアドレスを指定（テスト用に自分に返ってくるメールアドレス設定してます）
			mimeMessage.setRecipients(Message.RecipientType.TO, "system.project.team38@kanda-it-school-system.com");

			// メールのタイトルを指定
			mimeMessage.setSubject("配送しました。", "iso-2022-jp");

			// メールの内容を指定
			mimeMessage.setText(user.getUsername() + "様\n\n配送しました。\n\nまたのご利用よろしくお願いします。", "iso-2022-jp");

			// メールの形式を指定
			mimeMessage.setHeader("Content-Type", "text/plain; charset=iso-2022-jp");

			// 送信日付を指定
			mimeMessage.setSentDate(new Date());

			// 送信します
			Transport.send(mimeMessage);

			// 送信成功
			System.out.println("送信に成功しました。");

		} catch (Exception e) {
			// e.printStackTrace();
			System.out.println("送信に失敗しました。\n" + e);
		}
	}
}
