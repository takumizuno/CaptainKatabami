package servlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import bean.User;
import dao.UserDAO;

public class UserInsertServlet extends HttpServlet {

	public void doPostt(HttpServletRequest request, HttpServletResponse response)throws ServletException,IOException{

		String error = "";
		String cmd = "";

		try {
			request.setCharacterEncoding("UTF-8");

			String username = request.getParameter("username");
			String userid = request.getParameter("userid");
			String password = request.getParameter("password");
			String email = request.getParameter("email");
			String address = request.getParameter("address");

			if(username.equals("")) {
				error = "氏名が未入力の為、会員登録は行えません。";
				cmd = "menu";
				return;
			}
			if(userid.equals("")) {
				error = "IDが未入力の為、会員登録は行えません。";
				cmd = "menu";
				return;
			}
			if(password.equals("")) {
				error = "パスワードが未入力の為、会員登録は行えません。";
				cmd = "menu";
				return;
			}
			if(email.equals("")) {
				error = "メールアドレスが未入力の為、会員登録は行えません。";
				cmd = "menu";
				return;
			}
			if(address.equals("")) {
				error = "住所が未入力の為、会員登録は行えません。";
				cmd = "menu";
				return;
			}

			User user = new User();
			user.setUsername(username);
			user.setUserid(userid);
			user.setPassword(password);
			user.setEmail(email);
			user.setAddress(address);
			user.setAuthority("2");

			UserDAO userDao = new UserDAO();

			if(userDao.selectByUser(userid).getUserid() != null) {
				error = "入力されたユーザーIDは既に登録済の為、会員登録は行えません。";
				cmd = "menu";
				return;
			}
			if(userDao.selectByEmail(email).getEmail() != null) {
				error = "入力されたメールアドレスは既に登録済の為、会員登録は行えません。";
				cmd = "menu";
				return;
			}

			userDao.insertUser(user);
		}catch(IllegalStateException e) {
			error = "DB接続エラーの為、会員登録は行えません。";
			cmd = "menu";
		}finally {
			if(error.equals("")) {
				request.getRequestDispatcher("/view/userMenu.jsp").forward(request, response);
			}else {
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}
}