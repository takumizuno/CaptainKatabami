package servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.*;
import bean.*;
import util.SendMail;


public class BuyConfirmServlet extends HttpServlet{


	protected void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
		//文字コード指定
		request.setCharacterEncoding("UTF-8");

		// セッションとリクエストパラメータから情報取得
		HttpSession session = request.getSession();

		User user = (User)session.getAttribute("user");

		ArrayList<Product> productList = (ArrayList<Product>) session.getAttribute("productList");
		ArrayList<Integer> quantityList= (ArrayList<Integer>) session.getAttribute("quantityList");

		OrderDAO orderDAO;
		CommentDAO commentDAO;

		String name= request.getParameter("name");
		String email= request.getParameter("email");
		String address = request.getParameter("address");
		String comment = request.getParameter("comment");

		String cmd= "/view/buyCompleted.jsp";

		int orderid;
		int productid;


		Order order;


		try {

			orderDAO= new OrderDAO();
			commentDAO= new CommentDAO();

			orderid= orderDAO.getLatestOrderId()+1;


			int i= 0;
			//DBへ注文情報を登録
			if(productList.size() > 0) {
				for(Product p : productList) {
					order = new Order();

					order.setOrderid(orderid);
					order.setProductid(p.getProductid());
					order.setQuantity(quantityList.get(i));
					if(user != null) {
						order.setUserid(user.getUserid());
					}
					order.setName(name);
					order.setEmail(email);
					order.setAddress(address);


					orderDAO.insert(order);
				}
			}

			// 備考欄commentの追加
			Comment comm = new Comment();
			comm.setOrderId(orderid);
			comm.setComment(comment);
			commentDAO.insert(orderid, comment);


			// フォワード先で使う情報をリクエストスコープに渡す
			request.setAttribute("productList", productList);
			request.setAttribute("quantityList", quantityList);
			request.setAttribute("name", name);
			request.setAttribute("email", email);
			request.setAttribute("address", address);

			request.setAttribute("comment", comment);

			//注文確定メールを送信する
			SendMail sendMail = new SendMail();
			sendMail.sendMailBuy(user,productList);		//ここ確認してほしい




		} catch (IllegalStateException e) {
			request.setAttribute("error", "DB接続エラーの為、購入は出来ません。");
			request.setAttribute("cmd", "logout");
			cmd= "/view/error.jsp";
		} catch (Exception e) {
			request.setAttribute("error", "エラーが発生した為、購入は出来ません。");
			request.setAttribute("cmd", "logout");
			cmd= "/view/error.jsp";
			System.out.println(e);
		} finally {
			request.getRequestDispatcher(cmd).forward(request, response);
		}
	}

}
