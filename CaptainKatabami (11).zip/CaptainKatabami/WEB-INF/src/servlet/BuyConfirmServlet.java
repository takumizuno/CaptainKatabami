package servlet;

import java.io.IOException;
import java.util.ArrayList;

import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.*;
import bean.*;
import util.SendMail;


public class BuyConfirmServlet extends HttpServlet{


	protected void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
		String error = "";
		String cmd = "";

		//文字コード指定
		request.setCharacterEncoding("UTF-8");

		// セッションとリクエストパラメータから情報取得
		HttpSession session = request.getSession();

		//getSession
		Order o=(Order)session.getAttribute("orderList");


		ArrayList<Order> order_list = (ArrayList<Order>) session.getAttribute("order_list");
		order_list.add(o);

		//request.getAttribute("order_list",order_list);
		//非会員があるため、userのセラーチェックしない
		User user = (User)session.getAttribute("user");
		//備考欄を持ってくる
		String comment = request.getParameter("comment");


		// カートの中身がない場合はerror.jspに遷移する
		if (order_list == null || order_list.isEmpty()) {
			error = "カートの中に何も無かったので購入は出来ません。";
			cmd = "menu";
			return;
		}


		try {
			OrderDAO orderDaoObj = new OrderDAO();

			ArrayList<Product> product_list = new ArrayList<Product>();

			//DBへ注文情報を登録

				for(Order order : order_list) {
					//Product product = productDaoObj.selectByProductid(order.getProductid());
					//product_list.add(product);

					Order oo=new Order();

					if(user != null) {
						oo.setUserid(user.getUserid());
					}else {
						//とりあえず非会員で'000'
						oo.setUserid("000");
					}


					//オーダーする商品の詳細
					//productid,name,imgpath,stock,price

					//注文者名

					oo.setProductid(order.getProductid());
					oo.setName(order.getName());
					//メール
					oo.setEmail(order.getEmail());
					//住所
					oo.setAddress(order.getAddress());
					//備考欄
					oo.setRemarks(comment);
					//数量
					oo.setQuantity(order.getQuantity());
					//非会員の場合
					if(user != null) {
						oo.setUserid(user.getUserid());
					}
					//現在の日付

					//入金、発送状況はデフォルト”１”
					//SQL set
					//注文登録
					orderDaoObj.insert(oo);
				}

			//ここは無視
			//CommentDAO commentDao=new CommentDAO();
			// 備考欄commentの追加
			//Comment comm = new Comment();
			//comm.setComment(comment);


			// フォワード先で使う情報をリクエストスコープに渡す
			//request.setAttribute("productList", productList);
			//request.setAttribute("quantityList", quantityList);
			//request.setAttribute("name",o.getName());
			//request.setAttribute("email", o.getName());
			//request.setAttribute("address", o.getAddress());

			//request.setAttribute("comment", comment);

			//注文確定メールを送信する
			SendMail sendMail = new SendMail();
			sendMail.sendMailBuy(user, product_list);


			//  セッションのorder_listをクリアする
			session.setAttribute("order_list", null);


		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、購入は出来ません。";
			cmd = "logout";

		} finally {
			// � エラーの有無でフォワード先を呼び分ける
			if (error.equals("")) {
				// エラーが無い場合はbuyConfirmed.jspにフォワードする
				request.getRequestDispatcher("/view/purchaseConfirmed.jsp").forward(
						request, response);
			} else {
				// エラーが有る場合はerror.jspにフォワードする
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(
						request, response);
			}

		}
	}
}