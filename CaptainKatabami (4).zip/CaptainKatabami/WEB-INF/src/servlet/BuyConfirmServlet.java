package servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.*;
import bean.*;
import util.SendMail;


public class BuyConfirmServlet extends HttpServlet{


	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("UTF-8");

		// セッションとリクエストパラメータから情報取得
		HttpSession session = req.getSession();

		User user = (User)session.getAttribute("user");
		ArrayList<Product> productList = (ArrayList<Product>) session.getAttribute("productList");
		ArrayList<Integer> quantityList= (ArrayList<Integer>) session.getAttribute("quantityList");

		OrderDAO orderDAO;
		//NoteDAO noteDAO;

		String buyerName= req.getParameter("name");
		String email= req.getParameter("email");
		String address = req.getParameter("address");
		//String comment = req.getParameter("comment");

		//String dest= "/view/buyCompleted.jsp";

		int orderNum;
		//int groupNum;


		Order order;


		try {

			orderDAO= new OrderDAO();
			noteDAO= new NoteDAO();

			orderNum= orderDAO.getLatestOrderNum()+1;
			groupNum=  new Random().nextInt();


			int i= 0;
			//DBへ注文情報を登録
			if(productList.size() > 0) {
				for(Product p : productList) {
					order = new Order();

					//order.setOrderNum(orderNum);
					//order.setGroupNum(groupNum);
					order.setProductId(p.getId());
					order.setQuantity(quantityList.get(i));
					if(user != null) {
						order.setBuyerId(user.getId());
					}
					//order.setName(buyerName);
					//order.setEmail(email);
					//order.setAddress(address);


					orderDAO.insert(order);
				}
			}

			// Noteの追加
			//Note note = new Note();
		//	note.setOrderNum(orderNum);
			//note.setComment(comment);
		//	noteDAO.insert(orderNum, comment);


			// フォワード先で使う情報をリクエストスコープに渡す
			req.setAttribute("productList", productList);
			req.setAttribute("quantityList", quantityList);
			req.setAttribute("name", buyerName);
			req.setAttribute("email", email);
			req.setAttribute("address", address);
			//
			//req.setAttribute("note", note);



			//注文確定メールを送信する
			SendMail sendMail = new SendMail();
			sendMail.sendMailBuy(user,product_list);	//←とりあえず引数を入れたので、訂正してください！


		} catch (IllegalStateException e) {
			req.setAttribute("error", "DB接続エラーの為、購入は出来ません。");
			req.setAttribute("cmd", "logout");
			dest= "/view/error.jsp";
		} catch (Exception e) {
			req.setAttribute("error", "エラーが発生した為、購入は出来ません。");
			req.setAttribute("cmd", "logout");
			dest= "/view/error.jsp";
			System.out.println(e);
		} finally {
			req.getRequestDispatcher(dest).forward(req, resp);
		}
	}

}
