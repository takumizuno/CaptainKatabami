package servlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import bean.*;
import dao.*;

public class LoginServlet extends HttpServlet {

	// パスワード保護の為POST送信（GETだとアドレスに入力データが見えてしまう為）
		public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

			//変数宣言
			String error = "";
			String cmd = "";

			try {

				//画面から送信される検索条件受け取りのためのエンコード設定
				request.setCharacterEncoding("UTF-8");

				//パラメータの取得
				String userid = request.getParameter("userid");
				String password = request.getParameter("password");

				//オブジェクト生成し、ユーザー情報を取得するメソッドを呼び出す
				UserDAO userDao = new UserDAO();
				User user = userDao.selectByUser(userid,password);
				User admin = userDao.selectByAdmin(userid, password);

				//インスタンス化
				User loginData = new User();

				//ユーザー情報があるかどうかチェックする
				if(user.getUserid() != null) {
					loginData = user;
					cmd = "member";
				}else if(admin.getUserid() != null) {
					loginData = admin;
					cmd = "admin";
				}else {
					// ユーザー情報がない場合 入力エラーメッセージを登録
					request.setAttribute("message", "入力データが間違っています！");
					cmd = "login";
					return;
				}

				//以下ユーザー情報ある場合の処理

				//取得したユーザー情報をセッションスコープにuserで登録
				HttpSession session = request.getSession();
				session.setAttribute("user", loginData);

				// クッキーに入力情報のuseridとpasswordを登録（５日間）
				Cookie userCookie = new Cookie("userid", loginData.getUserid());
				userCookie.setMaxAge(60 * 60 * 24 * 5);
				response.addCookie(userCookie);

				Cookie passCookie = new Cookie("password", loginData.getPassword());
				passCookie.setMaxAge(60 * 60 * 24 * 5);
				response.addCookie(passCookie);


			}catch(IllegalStateException e) {
				error = "DB接続エラーの為、ログインは出来ません。";
				cmd = "logout";
			}catch(Exception e) {
				error = "予期せぬエラーが発生しました。<br>" + e ;
				cmd = "logout";
			}finally {

				//エラーの有無でフォワード先を呼び分け
				if(error.equals("")) {

					//エラーがない場合、ユーザー情報の有無や権限によってフォワード先呼び分け
					if(cmd.equals("member")) {
						//ユーザー情報があり、かつ権限がの場合、userMenu.jspにフォワード
						request.getRequestDispatcher("/view/userMenu.jsp").forward(request, response);
					}else if(cmd.equals("admin")) {
						//ユーザー情報があり、かつ権限が管理者、adminMenu.jspにフォワード
						request.getRequestDispatcher("/view/adminMenu.jsp").forward(request, response);
					}else {
						//ユーザー情報がない場合、login.jspにフォワード
						request.getRequestDispatcher("/view/login.jsp").forward(request, response);
					}

				}else {
					//エラーがあった場合は、error.jspにフォワード
					request.setAttribute("error", error);
					request.setAttribute("cmd", cmd);
					request.getRequestDispatcher("/view/error.jsp").forward(request, response);
				}
			}


		}

}
