package servlet;

import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.*;
import bean.*;
import util.SendMail;

public class BuyConfirmServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String error = "";
		String cmd = "";

		// 文字コード指定
		request.setCharacterEncoding("UTF-8");

		// セッションとリクエストパラメータから情報取得
		HttpSession session = request.getSession();

		//会員のカートの中身
		ArrayList<Order> order_list = (ArrayList<Order>) session.getAttribute("order_list");
		//非会員のカートの中身
		Product product_info = (Product) session.getAttribute("pList");

		// 非会員があるため、userのセラーチェックしない
		User user = (User) session.getAttribute("user");
		// 備考欄を持ってくる
		String comment = request.getParameter("comment");

		// カートの中身がない場合はerror.jspに遷移する
		if (order_list == null || order_list.isEmpty()) {
			error = "カートの中に何も無かったので購入は出来ません。";
			cmd = "menu";
			return;
		}

		// カートの中身を処理
		try {

			// DB接続および注文関連テーブル操作
			OrderDAO order_Dao = new OrderDAO();

			// 商品情報リスト
			ArrayList<Product> product_list = new ArrayList<Product>();

			// 注文者と注文情報のマージ用
			Order order_info = new Order();
			// 注文者IDを設定

			//会員処理
			if (user != null) {
				order_info.setUserid(user.getUserid());
				// DBへ注文情報を登録
				// カートの中身を order に一つ取り出す
				int count = 0;
				for (Order order : order_list) {

					// 注文した商品ID
					order_info.setProductid(order.getProductid());
					// 注文した人の名前
					order_info.setName(order.getName());
					// 注文した人のメール
					order_info.setEmail(order.getEmail());
					// 注文した人の住所
					order_info.setAddress(order.getAddress());
					// 注文した人の備考欄
					order_info.setRemarks(comment);
					// 注文した商品の数量
					order_info.setQuantity(order.getQuantity());
					int quantity = Integer.parseInt(request.getParameter("quantity"+count));
					order_info.setQuantity(quantity);

					//// DBへ注文情報を登録
					order_Dao.insert(order_info);

					//商品情報の更新
					ProductDAO product_Dao = new ProductDAO();
					Product product = product_Dao.selectByProductid(order_info.getProductid());
					product_Dao.update(product,order_info);

					count++;

				}

			} else {
				//非会員処理
				UserDAO userDao = new UserDAO();
				int randomNo = 0;

				while(true) {
					randomNo = (int)(Math.random() * 1000 );
					user = userDao.selectByUser(String.valueOf(randomNo));

					if (user.getUserid() != null) {
						continue;
					}else {
						break;
					}
				}

				String userid = String.valueOf(randomNo);
				String name = request.getParameter("name");
				String email = request.getParameter("email");
				String address = request.getParameter("address");
				String product_id	= product_info.getProductid();
				String product_quantity	= request.getParameter("product_quantity");

				//非会員のユーザー登録
				User nonUser = new User();
				nonUser.setUsername(name);
				nonUser.setUserid(userid);
				nonUser.setPassword("");
				nonUser.setEmail(email);
				nonUser.setAddress(address);
				nonUser.setAuthority("2");

				//非会員登録
				userDao.insertUser(nonUser);

				// 注文した商品の登録
				order_info.setUserid(userid);
				order_info.setProductid(product_id);
				order_info.setName(name);
				order_info.setEmail(email);
				order_info.setAddress(address);
				order_info.setQuantity(Integer.parseInt(product_quantity));

				// DBへ注文情報を登録
				order_Dao.insert(order_info);

				//商品情報の更新
				ProductDAO product_Dao = new ProductDAO();
				Product product = product_Dao.selectByProductid(order_info.getProductid());
				product_Dao.update(product,order_info);

			}

			// 注文確定メールを送信する
			SendMail sendMail = new SendMail();
			sendMail.sendMailBuy(user);

			// セッションのorder_listをクリアする
			session.setAttribute("order_list", null);

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、購入は出来ません。";
			cmd = "logout";

		} finally {
			// エラーの有無でフォワード先を呼び分ける
			if (error.equals("")) {
				// エラーが無い場合はbuyConfirmed.jspにフォワードする
				request.getRequestDispatcher("/view/purchaseConfirmed.jsp").forward(request, response);
			} else {
				// エラーが有る場合はerror.jspにフォワードする
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}
}