package servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.*;
import javax.servlet.http.*;

import bean.*;
import dao.*;

/**
 * UniformSystemにおける商品削除機能に関する処理をおこなうサーブレットクラス
 *
 * @author
 *
 */
public class ProductDeleteServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String error = "";
		String cmd = "";

		try {
			// 入力データの文字コードの指定
			request.setCharacterEncoding("UTF-8");

			// � productidのパラメータを取得する
			String productid = (String)request.getParameter("productid");

			// � DAOオブジェクトをインスタンス化する
			ProductDAO productDao = new ProductDAO();

			// 更新対象の有無のエラーチェック
			if (productDao.selectByProductid(productid).getProductid() == null) {
				error = "削除対象の商品が存在しない為、書籍削除処理は行えませんでした。";
				cmd = "list";
				return;
			}

			// � 書籍の削除をおこなうメソッドを呼び出す
			productDao.delete(productid);

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、商品削除処理は行えませんでした。";
			cmd = "menu";
		} finally {
			// � エラーの有無でフォワード先を呼び分ける
			if (error.equals("")) {
				// エラーが無い場合はProductListにフォワード
				request.getRequestDispatcher("/productList")
						.forward(request, response);
			} else {
				// エラーが有る場合はerror.jspにフォワードする
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(
						request, response);
			}
		}

	}
}
