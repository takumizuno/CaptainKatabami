package servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Order;
import bean.Product;
import bean.User;
import dao.ProductDAO;

public class ShowCartServlet extends HttpServlet {

	/**
	 * セッションのカート情報を表示する
	 *
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String error = "";
		String cmd = "";

		try {

			//文字コード指定
			request.setCharacterEncoding("UTF-8");

			// セッションからuserを受け取る
			HttpSession session = request.getSession();
			User user = (User) session.getAttribute("user");

			// セッション切れの場合はerror.jspに遷移する
			if (user == null) {
				error = "セッション切れの為、カート状況は確認出来ません。";
				cmd = "logout";
				return;
			}

			// 入力パラメータを取得
			String delno = (String) request.getParameter("delno");

			ArrayList<Order> order_list = (ArrayList<Order>) session.getAttribute("order_list");

			if (delno != null) {
				order_list.remove(Integer.parseInt(delno));
				session.setAttribute("order_list", order_list);
			}

			//ProductDAOをインスタンス化し、関連メソッドを該当のorder_list（カートデータ）分だけ呼び出す
			ProductDAO productDao = new ProductDAO();

			ArrayList<Product> product_list = new ArrayList<Product>();

			if (order_list != null) {
				for (Order order : order_list) {
					Product product = productDao.selectByProductid(order.getProductid());
					product_list.add(product);
				}
			}

			request.setAttribute("product_list", product_list);

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、カート状況は確認できません。";
			cmd = "logout";

		} catch (NumberFormatException e) {
			error = "パラメータの値が不正です。カートの商品の削除は出来ません。";
			cmd= "productList";
		}finally {
			// エラーがない場合
			if (error.equals("")) {
				request.getRequestDispatcher("view/userCart.jsp").forward(request, response);

				// エラーの場合
			} else {
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}

}
