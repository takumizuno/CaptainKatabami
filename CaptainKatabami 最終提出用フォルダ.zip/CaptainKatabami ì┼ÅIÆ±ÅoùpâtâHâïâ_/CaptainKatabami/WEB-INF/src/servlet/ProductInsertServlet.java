package servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.*;
import javax.servlet.http.*;

import bean.Product;
import dao.ProductDAO;

/**
 * UniformSystemにおける商品一覧表示機能に関する処理をおこなうサーブレットクラス
 *
 * @author
 *
 */


public class ProductInsertServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String error = "";
		String cmd = "";

		try {
			// 入力データの文字コードの指定
			request.setCharacterEncoding("UTF-8");

			// � productid、productname、img、stock、priceの入力パラメータを取得する
			String productid = request.getParameter("productId"); //商品番号
			String productname = request.getParameter("productName"); //商品名
			String img = request.getParameter("productImage"); //商品図
			String strStock = request.getParameter("Stock"); //在庫数
			String strPrice = request.getParameter("Price"); //価格

			// � 取得したパラメータの各エラーチェックをおこなう
			// 全データの空白チェック（データが入力されているかどうか）
			if (productid.equals("")) {
				error = "商品番号が未入力の為、商品登録処理は行えませんでした。";
				cmd = "list";
				return;
			}

			if (productname.equals("")) {
				error = "タイトルが未入力の為、商品登録処理は行えませんでした。";
				cmd = "list";
				return;
			}

			if (img.equals("")) {
				error = "商品図が未挿入の為、商品登録処理は行えませんでした。";
				cmd = "list";
				return;
			}

			if (strStock.equals("")) {
				error = "在庫数が未入力の為、商品登録処理は行えませんでした。";
				cmd = "list";
				return;
			}

			int stock;
			try {
				// 価格値チェック（整数かどうか）
				stock = Integer.parseInt(strStock);
			} catch (NumberFormatException e) {
				error = "在庫数の値が不正の為、商品登録処理は行えませんでした。";
				cmd = "list";
				return;
			}

			if (strPrice.equals("")) {
				error = "価格が未入力の為、商品登録処理は行えませんでした。";
				cmd = "list";
				return;
			}

			int price;
			try {
				// 価格値チェック（整数かどうか）
				price = Integer.parseInt(strPrice);
			} catch (NumberFormatException e) {
				error = "価格の値が不正の為、商品登録処理は行えませんでした。";
				cmd = "list";
				return;
			}

			// ProductDAOオブジェクト生成
			ProductDAO productDao = new ProductDAO();

			// ISBNの重複チェック
			if (productDao.selectByProductid(productid).getProductid() != null) {
				error = "入力商品番号は既に登録済みの為、商品登録処理は行えませんでした。";
				cmd = "list";
				return;
			}

			// � Bookのオブジェクトを生成し、各setterメソッドを利用し、productid、productname、img、stock、priceを設定する
			Product product = new Product();
			product.setProductid(productid);
			product.setProductname(productname);
			product.setImgpath(img);
			product.setStock(stock);
			product.setPrice(price);


			// � �で生成したBookのオブジェクトを引数として、関連メソッドを呼び出す
			productDao.insert(product);

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、商品登録処理は行えませんでした。";
			cmd = "menu";
		} finally {
			// �エラーの有無でフォワード先を呼び分ける
			if (error.equals("")) {
				// エラーが無い場合はProductListServletにフォワード
				request.getRequestDispatcher("/productList")
						.forward(request, response);
			} else {
				// エラーが有る場合はerror.jspにフォワードする
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(
						request, response);
			}
		}
	}
}