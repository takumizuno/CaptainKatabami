package servlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.ArrayList;
import bean.User;
import dao.UserDAO;

public class UserUpdateServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		UserDAO objDao = new UserDAO();
		User user = new User();
		String error = null;
		String cmd = null;

		request.setCharacterEncoding("UTF-8");

		String name = request.getParameter("username");
		String id = request.getParameter("userid");
		String password = request.getParameter("password");
		String email = request.getParameter("email");
		String address = request.getParameter("address");

		try {
			if (name == null || name.equals("")) {
				error = "氏名が未入力です。";
				cmd = "menu";
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				return;
			}
			if (id == null || id.equals("")) {
				error = "IDが未入力です。";
				cmd = "menu";
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				return;
			}
			if (password == null || password.equals("")) {
				error = "パスワードが未入力です。";
				cmd = "menu";
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				return;
			}
			if (email == null || email.equals("")) {
				error = "メールアドレスが未入力です。";
				cmd = "menu";
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				return;
			}
			if (address == null || address.equals("")) {
				error = "住所が未入力です。";
				cmd = "menu";
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				return;
			}
			user.setUsername(request.getParameter("username"));
			user.setUserid(request.getParameter("userid"));
			user.setPassword(request.getParameter("password"));
			user.setEmail(request.getParameter("email"));
			user.setAddress(request.getParameter("address"));

			objDao.updateUser(user);

		} catch (Exception e) {
			error = "DB接続エラーの為、会員情報更新は行えません。";
			cmd = "menu";
			request.setAttribute("error", error);
			request.setAttribute("cmd", cmd);
		} finally {
			if (error.equals("")) {
				request.getRequestDispatcher("/view/userMenu.jsp").forward(request, response);
			} else {
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}
}