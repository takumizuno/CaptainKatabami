package servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.*;
import javax.servlet.http.*;

import bean.*;
import dao.*;

/**
 * 商品管理システムにおける商品一覧表示機能に関する処理をおこなうサーブレットクラス
 *
 * @author
 *
 */


public class ProductListServlet extends HttpServlet {


	/**
	 * Get送信の場合
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String error = "";
		String cmd = "";

		try {

			//セッションスコープ受け取り
			HttpSession session = request.getSession();
			User sessionUser = (User)session.getAttribute("user");

			//nullチェック
			if(sessionUser != null) {
				//権限振り分け
				if(sessionUser.getAuthority().equals("1")) {
					cmd = "admin";
				}else {
					//userだと混同するので、会員をMemberに
					cmd = "member";
				}
			}else {
				cmd = "nonMember";
			}

			// �ProductDAOをインスタンス化する
			ProductDAO productDao = new ProductDAO();

			// � 関連メソッドを呼び出し、戻り値としてProductオブジェクトのリストを取得する
			ArrayList<Product> productList = productDao.selectAll();

			// � �で取得したListをリクエストスコープに"product_list"という名前で格納する
			request.setAttribute("product_list", productList);

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、一覧表示は行えませんでした。";
			cmd = "menu";
		}catch(Exception e) {
			error = "予期せぬエラーが発生しました。<br>" + e ;
			cmd = "logout";
		} finally {
			// エラーの有無でフォワード先を呼び分ける
			if (error.equals("")) {
				// エラーが無い場合、cmdで呼び分け
				if(cmd.equals("admin")) {
					request.getRequestDispatcher("/view/productList.jsp").forward(request,response);
				}else if(cmd.equals("member")) {
					request.getRequestDispatcher("/view/userMenu.jsp").forward(request, response);
				}else {
					request.getRequestDispatcher("/view/nonUserMenu.jsp").forward(request, response);
				}

			} else {
				// エラーが有る場合はerror.jspにフォワードする
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(
						request, response);
			}
		}
	}


		/**
		 * Post送信の場合
		 */
		public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			String error = "";
			String cmd = "";

			try {

				//セッションスコープ受け取り
				HttpSession session = request.getSession();
				User sessionUser = (User)session.getAttribute("user");

				//nullチェック
				if(sessionUser != null) {
					//権限振り分け
					if(sessionUser.getAuthority().equals("1")) {
						cmd = "admin";
					}else {
						//userだと混同するので、会員をMemberに
						cmd = "member";
					}
				}else {
					cmd = "nonMember";
				}

				// �ProductDAOをインスタンス化する
				ProductDAO productDao = new ProductDAO();

				// � 関連メソッドを呼び出し、戻り値としてProductオブジェクトのリストを取得する
				ArrayList<Product> productList = productDao.selectAll();

				// � �で取得したListをリクエストスコープに"product_list"という名前で格納する
				request.setAttribute("product_list", productList);

			} catch (IllegalStateException e) {
				error = "DB接続エラーの為、一覧表示は行えませんでした。";
				cmd = "menu";
			}catch(Exception e) {
				error = "予期せぬエラーが発生しました。<br>" + e ;
				cmd = "logout";
			} finally {
				// エラーの有無でフォワード先を呼び分ける
				if (error.equals("")) {
					// エラーが無い場合、cmdで呼び分け
					if(cmd.equals("admin")) {
						request.getRequestDispatcher("/view/productList.jsp").forward(request,response);
					}else if(cmd.equals("member")) {
						request.getRequestDispatcher("/view/userMenu.jsp").forward(request, response);
					}else {
						request.getRequestDispatcher("/view/nonUserMenu.jsp").forward(request, response);
					}

				} else {
					// エラーが有る場合はerror.jspにフォワードする
					request.setAttribute("error", error);
					request.setAttribute("cmd", cmd);
					request.getRequestDispatcher("/view/error.jsp").forward(
							request, response);
				}
			}
		}
}
