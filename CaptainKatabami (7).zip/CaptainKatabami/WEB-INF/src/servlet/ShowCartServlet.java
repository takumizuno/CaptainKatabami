package servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Product;
import bean.User;

public class ShowCartServlet extends HttpServlet {

	/**
	 * セッションのカート情報を表示する
	 *
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String error = "";
		String cmd = "";

		try {

			//文字コード指定
			request.setCharacterEncoding("UTF-8");

			// セッションからuserを受け取る
			HttpSession session = request.getSession();
			User user = (User) session.getAttribute("user");

			// 入力パラメータを取得
			String delno = (String) request.getParameter("delno");
			String index= (String)request.getParameter("index");
			String quantity= (String)request.getParameter("quantity");


			// セッションからproductListとquantityListを取得
			ArrayList<Product> productList  = (ArrayList<Product>) session.getAttribute("productList");
			ArrayList<Integer> quantityList= (ArrayList<Integer>)session.getAttribute("quantityList");


			// delnoが「null」でないかつ""場合productListから該当商品を削除
			if (delno != null && !delno.equals("")) {
				int delNum= Integer.parseInt(delno);
				if(productList!= null && (0<= delNum && delNum< productList.size())) {
					productList.remove(delNum);
					quantityList.remove(delNum);
					//セッション上書き
					session.setAttribute("productList", productList);
					session.setAttribute("quantityList", quantityList);

				}
			}else if((index!= null && !index.equals(""))
					&& (quantity!= null && !quantity.equals(""))) {
				// 個数変更
				quantityList.set(Integer.parseInt(index),
						Integer.parseInt(quantity));
				//セッション上書き
				session.setAttribute("quantityList", quantityList);
			}

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、カート状況は確認できません。";
			cmd = "logout";

		} catch (NumberFormatException e) {
			error = "パラメータの値が不正です。カートの商品の削除は出来ません。";
			cmd= "productList";
		}finally {
			// エラーがない場合
			if (error.equals("")) {
				request.getRequestDispatcher("/view/showCart.jsp").forward(request, response);

				// エラーの場合
			} else {
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}

}
