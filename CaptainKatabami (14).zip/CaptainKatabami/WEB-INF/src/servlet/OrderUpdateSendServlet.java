package servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.*;
import dao.*;
import util.SendMail;

public class OrderUpdateSendServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String error = "";
		String cmd = "";

		try {
			// 文字コード指定
			request.setCharacterEncoding("UTF-8");

			// パラメータの値を取得
			String orderid = request.getParameter("orderid");

			// OrderDAOオブジェクト生成
			OrderDAO orderDao = new OrderDAO();

			// 登録用のupdateメソッド呼び出し
			orderDao.ordershippingUpdate(orderid);

			// メール機能/user,book_listを引数にする
			SendMail send = new SendMail();
			send.sendMailShipping();

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、書籍登録処理は行えませんでした。";
			cmd = "logout";
		} finally {
			// エラーの有無でフォワード先を呼び分ける
			if (error.equals("")) {
				// エラーが無い場合はListServletにフォワード
				request.getRequestDispatcher("/view/sendConfirm.jsp").forward(request, response);
			} else {
				// エラーが有る場合はerror.jspにフォワードする
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}
}