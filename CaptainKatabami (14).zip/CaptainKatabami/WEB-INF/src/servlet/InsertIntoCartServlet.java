package servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.ProductDAO;
import bean.Product;
import bean.Order;
import bean.User;

public class InsertIntoCartServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String error="";
		String cmd=request.getParameter("cmd");
		int orderNum=0;

		try {

			//セッションからUserオブジェクトを取得
			HttpSession session = request.getSession();
			User user = (User) session.getAttribute("user");


			//idのパラメータを取得
			String productid = request.getParameter("productid");
			// 個数を取得

			ProductDAO productDaoObj = new ProductDAO();
			Product product = productDaoObj.selectByProductid(productid);

			request.setAttribute("product", product);

			ArrayList<Order> order_list = (ArrayList<Order>) session.getAttribute("order_list");

			Order order = new Order();

			order.setProductid(product.getProductid());

			request.setAttribute("order", order);


			// 取得できなかった場合はArrayList<Order>配列を新規で作成する
			if (order_list == null) {
				order_list = new ArrayList<Order>();
			}

			// OrderオブジェクトをList配列に追加し、セッションスコープに"order_list"という名前で登録する
			order_list.add(order);
			session.setAttribute("order_list", order_list);


		}catch(IllegalStateException e) {
			error = "DB接続エラーの為、カートに追加出来ません。";
			cmd = "logout";
		}finally {

			// エラーの有無でフォワード先を呼び分ける
			if (error.equals("")) {
				// フォワード
				if(cmd.equals("nonUser")) {
					request.getRequestDispatcher("/view/nonUserCart.jsp").forward(request, response);
				}else {
					request.getRequestDispatcher("/view/userCart.jsp").forward(request, response);
				}
			}else {
				// エラーが有る場合はerror.jspにフォワードする
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);

			}
		}


	}

}
