package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import bean.Comment;

public class CommentDAO {

	private static String RDB_DRIVE = "com.mysql.jdbc.Driver";
	private static String URL = "jdbc:mysql://localhost/uniformdb";
	private static String USER = "root";
	private static String PASSWD = "root123";

	// データベースと繋ぐメソッド
	public static Connection getConnection() {
		try {
			Class.forName(RDB_DRIVE);
			Connection con = DriverManager.getConnection(URL, USER, PASSWD);
			return con;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

	// 実引数のorderNumを基にデータベースから該当する情報を引き出し、commentに格納する。
	public Comment selectByOrderid(int orderid) {

		Connection con = null;
		Statement smt = null;


		Comment comment = new Comment();

		try {
			con = getConnection();
			smt = con.createStatement();

			// SQL文の準備
			//comment table 欲しい
			String sql = "SELECT userid,orderid,comment FROM commenttable WHERE orderid = '" + orderid + "'";

			ResultSet rs = smt.executeQuery(sql); // ここでSQL文発行

			while(rs.next()) {
				comment.setUserId(rs.getInt("userid"));

				comment.setOrderId(rs.getInt("orderid"));
				comment.setComment(rs.getString("comment"));
			}

		}catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {try {smt.close();} catch (SQLException ignore) {}}
			if (con != null) {try {con.close();} catch (SQLException ignore) {}}
		}

		return comment; // 各値を格納したnoteを戻り値として返す。
	}

	//orderid,commentを引数に、新追加できる
	public int insert(int orderid, String comment) {

		Connection con = null;
		Statement smt = null;

		// return用変数
		int count = 0;

		try {
			con = getConnection();
			smt = con.createStatement();

			//comment備考欄 table 欲しい
			String sql = "INSERT INTO commenttable VALUES( NULL, " + orderid + " , '" + comment + "')";

			count = smt.executeUpdate(sql); // ここでSQL文発行

		}catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {try {smt.close();} catch (SQLException ignore) {}}
			if (con != null) {try {con.close();} catch (SQLException ignore) {}}
		}
		return count;
	}

}