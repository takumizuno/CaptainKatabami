package servlet;

import java.io.*;
import java.util.ArrayList;
import javax.servlet.*;
import javax.servlet.http.*;
import dao.ProductDAO;
import bean.Product;

public class SearchServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
		String error = "";
		String cmd = "";

		try {
			request.setCharacterEncoding("UTF-8");

			String name = request.getParameter("productName");
			ProductDAO objDao = new ProductDAO();

			ArrayList<Product> productList = objDao.search(name);

			request.setAttribute("productList", productList);

		}catch(IllegalStateException e) {
			error = "DB接続エラーの為、表示出来ませんでした。";
			cmd = "menu";
		}finally {
			if(error.equals("")) {
				request.getRequestDispatcher("/view/productList.jsp").forward(request, response);
			}else {
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}
}