package servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.ProductDAO;
import bean.Product;
import bean.User;

public class InsertIntoCartServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String error="";
		String cmd="";

		try {

			//セッションからUserオブジェクトを取得
			HttpSession session = request.getSession();
			User user = (User) session.getAttribute("user");


			//idのパラメータを取得
			String productId = request.getParameter("productid");
			// 個数を取得
			int quantity= Integer.parseInt(request.getParameter("orderQuantity"));

			//ProductDAOをインスタンス化し、商品情報の検索
			ProductDAO productDaoObj = new ProductDAO();
			Product product = productDaoObj.selectByProductid(productId);

			ArrayList<Product> productList= (ArrayList<Product>)session.getAttribute("productList");
			ArrayList<Integer> quantityList= (ArrayList<Integer>)session.getAttribute("quantityList");

			//取得できなかった場合はArrayList<Order>を新規で作成
			if(productList == null) {
				productList = new ArrayList<>();
				quantityList= new ArrayList<>();
			}

			//orderオブジェクトをList配列に追加し、セッションスコープに"order_list"という名前で登録
			productList.add(product);
			quantityList.add(quantity);
			session.setAttribute("productList", productList);
			session.setAttribute("quantityList", quantityList);

		}catch(IllegalStateException e) {
			error = "DB接続エラーの為、カートに追加出来ません。";
			cmd = "logout";
		}finally {

			// エラーの有無でフォワード先を呼び分ける
			if (error.equals("")) {
				// フォワード
				request.getRequestDispatcher("/ProductListServlet").forward(request, response);
			}else {
				// エラーが有る場合はerror.jspにフォワードする
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);

			}
		}


	}

}
