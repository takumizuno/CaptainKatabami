package servlet;

import java.io.IOException;

import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import bean.OrderAdminItem;
import dao.OrderAdminItemDAO;

public class OrderListServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String error = "";
		String cmd = "";


		try {
			// OrderAdminItemDAOをインスタンス化し、関連メソッドを呼び起こす
			OrderAdminItemDAO orderAdminItemDao = new OrderAdminItemDAO();

			// 戻り値として、OrderAdminItemオブジェクトのリストを取得する
			ArrayList<OrderAdminItem> order_list = orderAdminItemDao.selectAll();

			// 取得したListをリクエストスコープに登録
			request.setAttribute("order_list", order_list);

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、注文状況確認は出来ません。";
			cmd = "logout";
		} finally {
			if (error.equals("")) {
				request.getRequestDispatcher("/view/orderList.jsp").forward(request, response);
			} else {
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}

		}
	}
}
